
#########################################################
##   IBM Rational SDP Evaluation Extension             ##
##   last updated: 20-Feb-2007                            ##
#########################################################


These license activation kits are used for extending the evaluation (a.k.a. 
trials) of certain Rational Software Development Platform 
(SDP) products.

=========================================
Important Notes
=========================================
The IBM Installation Manager must be used to install these evaluation
extension kits. If you are using IBM Installation Manager version 1.0 
and if you need to extend the evaluation more than once, then
you need to update the IBM Installation Manager to version 1.0.0.2 or 
higher for installing a second (or more) evaluation extension.

=========================================
Installation instructions
=========================================
To install the license key:
1. Login as user with Adminstrator privilege
2. Extract the contents of this .zip file to a new folder
3. Start IBM Installation Manager and select "Manage Licenses"
4. Select a product then choose Import product activation kit option
5. Browse to the jar file that you unzipped in step 2, click on next then finish
6. The license activation kit will be installed. To view the new product expiration date, 
    you can select Manage License in IBM Installation Manager 
    or view it through Help -> License status in a SDP product.
5. The evaluation extension process is complete and you may continue
   to use the Rational SDP evaluation

