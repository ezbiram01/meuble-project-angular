import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-porte-monteau',
  templateUrl: './porte-monteau.component.html',
  styleUrls: ['./porte-monteau.component.css']
})
export class PorteMonteauComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
