import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conception',
  templateUrl: './conception.component.html',
  styleUrls: ['./conception.component.css']
})
export class ConceptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
