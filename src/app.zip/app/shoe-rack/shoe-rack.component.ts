import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shoe-rack',
  templateUrl: './shoe-rack.component.html',
  styleUrls: ['./shoe-rack.component.css']
})
export class ShoeRackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
