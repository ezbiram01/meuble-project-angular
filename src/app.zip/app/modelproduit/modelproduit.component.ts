import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modelproduit',
  templateUrl: './modelproduit.component.html',
  styleUrls: ['./modelproduit.component.css']
})
export class ModelproduitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
